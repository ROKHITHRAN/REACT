1. Select the required branch
2.Download the code
3. Run --> npm install
4. Run --> npm install react-router-dom --save
5. npm start
